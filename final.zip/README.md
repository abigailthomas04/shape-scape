SUB SURGE

Final project for CSC 1980 and CSC 2280

To play, you will need:
- to install Pygame
- Python 2 or later

 DIRECTIONS:
- Click the space bar to start game
- Continue clicking the space bar to hop
- Don't just hold down the space bar....cuz that's lame
- ^^ Don't be lame
- Avoid the moving shipwreck obstacles to hop to the surface of the ocean !!
- Click the space bar to restart

To code the hopping effect and create gravity, I watched a flappy bird tutorial by @russs123 !!




